<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>2024<a href="#"></a><a href="https://www.spruko.com/"></a></span>
		</div>
	</div>
<!-- Footer closed -->
